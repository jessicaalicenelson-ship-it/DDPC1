# Davis Doulas Postpartum Care — website rebuild

## Files
- `index.html` — responsive website, with mother-first marketing, gift path, packages, Instagram CTA, personal About section and lead form.
- `assets/family-photo.png` — user-supplied family photo.
- `assets/final-logo.png` — ADD YOUR FINAL APPROVED LOGO HERE. The page falls back to a DD monogram until the correct final logo is supplied. We intentionally do not substitute an older logo.
- `google-apps-script.gs` — Google Sheets form receiver.

## Connect lead capture
1. Create a Google Sheet called `Davis Doulas Leads`. In the Sheet, open Extensions > Apps Script.
2. Paste the entire `google-apps-script.gs` file, save.
3. Deploy > New deployment > Web app. Execute as **Me**, access **Anyone** (required for anonymous website visitors). Authorize the script. This creates a public form endpoint: do not use the form for health data or highly sensitive information.
4. Copy the `/exec` URL and paste it between the quotes in `const GOOGLE_SCRIPT_URL = '';` in `index.html`.
5. Upload the whole folder to a static hosting service (Netlify or GitHub Pages). Test a submission and verify that a row appears in the Leads sheet.
6. Uncomment the optional `MailApp.sendEmail` line in the Apps Script to receive alerts, and enter your own email. After editing Apps Script redeploy a **new version**.

## Before publishing
- Insert the actual latest approved logo into `assets/final-logo.png`.
- Review the first-person About section for voice and accuracy; it deliberately avoids unverified credentials and uses a generic introduction instead of a made-up name.
- Confirm business phone/email; the form requests phone and email but does not publish the owner's direct contact details.
- Verify Instagram handle `raisingyouwithgrace` belongs to you before public release.
- Review privacy, opt-in, accessibility, and gift/payment terms. Ask a professional if your jurisdiction requires a formal privacy policy.
- For a live site already managed through ChatGPT, this package is a rebuilt static-code version, **not** an update to the existing published project.
