/** Copy into Extensions > Apps Script in the Google Sheet that will receive leads. */
const SHEET_NAME = 'Leads';
const HEADERS = ['Received at','Name','Phone','Email','Lead type','Package','Timing','City','Contact method','Message','Source','Page URL','Consent'];
function doPost(e) {
  try {
    const p = (e && e.parameter) || {};
    if (p.website) return reply_(false); // honeypot
    if (!p.name || !p.phone || !p.email || p.consent !== 'yes') return reply_(false);
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME) || SpreadsheetApp.getActiveSpreadsheet().insertSheet(SHEET_NAME);
    if (sheet.getLastRow() === 0) sheet.appendRow(HEADERS);
    // Prevent spreadsheet formula injection for any user-provided field.
    const safe = v => { const s=String(v || '').slice(0,1500); return /^[=+\-@\t\r]/.test(s) ? "'"+s : s; };
    sheet.appendRow([new Date(),safe(p.name),safe(p.phone),safe(p.email),safe(p.leadType),safe(p.package),safe(p.timing),safe(p.city),safe(p.contactMethod),safe(p.message),safe(p.source),safe(p.page),safe(p.consent)]);
    // Optional immediate email alert: uncomment and replace with your own email.
    // MailApp.sendEmail('YOUR_EMAIL@EXAMPLE.COM', 'New Davis Doulas lead', 'New inquiry from '+p.name+' ('+p.contactMethod+'). Open your linked spreadsheet.');
    return reply_(true);
  } catch(err) { console.error(err); return reply_(false); }
}
function reply_(success) {
  return HtmlService.createHtmlOutput('<!doctype html><html><body><script>window.parent.postMessage({type:"davis-doulas-lead",success:'+Boolean(success)+'},"*");<\/script></body></html>');
}
